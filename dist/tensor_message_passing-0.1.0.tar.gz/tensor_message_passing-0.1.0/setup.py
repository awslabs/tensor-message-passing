# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['tensor_message_passing']

package_data = \
{'': ['*']}

install_requires = \
['black>=23.3.0,<24.0.0',
 'isort>=5.12.0,<6.0.0',
 'pre-commit>=3.3.3,<4.0.0',
 'pytest>=7.3.2,<8.0.0']

setup_kwargs = {
    'name': 'tensor-message-passing',
    'version': '0.1.0',
    'description': '',
    'long_description': '## My Project\n\nTODO: Fill this README out!\n\nBe sure to:\n\n* Change the title in this README\n* Edit your repository description on GitHub\n\n## Security\n\nSee [CONTRIBUTING](CONTRIBUTING.md#security-issue-notifications) for more information.\n\n## License\n\nThis library is licensed under the MIT-0 License. See the LICENSE file.\n\n',
    'author': 'Nicola Pancotti',
    'author_email': 'npancott@amazon.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.11,<4.0',
}


setup(**setup_kwargs)
